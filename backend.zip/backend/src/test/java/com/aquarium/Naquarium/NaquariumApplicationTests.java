package com.aquarium.Naquarium;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class NaquariumApplicationTests {

	@Test
	void contextLoads() {
	}

}
