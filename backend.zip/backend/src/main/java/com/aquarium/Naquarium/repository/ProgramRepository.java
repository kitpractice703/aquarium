package com.aquarium.Naquarium.repository;
import com.aquarium.Naquarium.entity.Program;
import org.springframework.data.jpa.repository.JpaRepository;
public interface ProgramRepository extends JpaRepository<Program, Long> {}