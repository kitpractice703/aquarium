package com.aquarium.Naquarium.repository;
import com.aquarium.Naquarium.entity.Exhibition;
import org.springframework.data.jpa.repository.JpaRepository;
public interface ExhibitionRepository extends JpaRepository<Exhibition, Long> {}