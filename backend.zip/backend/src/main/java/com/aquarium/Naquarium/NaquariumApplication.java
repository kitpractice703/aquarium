package com.aquarium.Naquarium;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class NaquariumApplication {

	public static void main(String[] args) {
		SpringApplication.run(NaquariumApplication.class, args);
	}

}
